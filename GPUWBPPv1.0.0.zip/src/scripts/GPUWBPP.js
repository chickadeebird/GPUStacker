#feature-id    Batch Processing > GPUWBPP
#feature-info  GPU-accelerated Weighted Batch PreProcessing front-end \
               for the AstroPipeline executable.
#feature-icon  GPUWBPP.svg

// ---------------------------------------------------------------------------
// GPUWBPP.js
// ===========================================================================
// PixInsight front-end for the AstroPipeline executable.
//
// Mimics the controls of AstroPipelineGUI.py and forwards them to a compiled
// AstroPipeline.exe (Windows) or AstroPipeline (macOS/Linux) build via the
// command-line arguments already implemented in AstroPipeline.py.
//
// The pipeline is invoked through a small batch/shell wrapper that this
// script writes to the system temp directory.  All paths and options are
// also persisted to a small CSV-style config file under the temp directory
// so that they survive across PixInsight sessions.
// ---------------------------------------------------------------------------

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>

#define VERSION "v1.0.0"
#define TITLE   "GPUWBPP"

// ---------------------------------------------------------------------------
// Platform detection
// ---------------------------------------------------------------------------
let CMD_EXEC, SCRIPT_EXT, EXE_NAME, IS_WIN;
if (CoreApplication.platform == "MSWINDOWS"
    || CoreApplication.platform == "Windows") {
   CMD_EXEC   = "cmd.exe";
   SCRIPT_EXT = ".bat";
   EXE_NAME   = "AstroPipeline.exe";
   IS_WIN     = true;
} else if (CoreApplication.platform == "MACOSX"
           || CoreApplication.platform == "macOS") {
   CMD_EXEC   = "/bin/sh";
   SCRIPT_EXT = ".sh";
   EXE_NAME   = "AstroPipeline";
   IS_WIN     = false;
} else {
   CMD_EXEC   = "/bin/sh";
   SCRIPT_EXT = ".sh";
   EXE_NAME   = "AstroPipeline";
   IS_WIN     = false;
}

let pathSeparator = IS_WIN ? "\\" : "/";
let scriptTempDir = File.systemTempDirectory + pathSeparator + "GPUWBPP";
let configFile    = scriptTempDir + pathSeparator + "gpuwbpp_config.csv";

if (!File.directoryExists(scriptTempDir)) {
   File.createDirectory(scriptTempDir);
}

// ---------------------------------------------------------------------------
// Persisted parameters
// ---------------------------------------------------------------------------
var pipelineParameters = {
   astroPipelineParentFolderPath: "",
   biasDir:  "",
   darkDir:  "",
   flatDir:  "",
   lightDir: "",
   saveDir:  "",
   useGpuMode:    "auto",
   vramBudgetMb:  0,
   masterMode: "use_if_available",
   equalizeFlatFluxes: true,
   autocropStacks:     true,
   saveRegistered:     false,
   weighting:          "psf_signal",
   lowKappa:  3.0,
   highKappa: 3.0,
   localnormDiagnostics: false,
   lineRemoval:           true,
   saveHoughIntermediates:false,
   lineWidth:             7,
   relMinLineSize:        10,
   threshMultFromMedian:  3.0,

   save: function () {
      try {
         let f = new File;
         f.createForWriting(configFile);
         f.outTextLn("astroPipelineParentFolderPath=" + this.astroPipelineParentFolderPath);
         f.outTextLn("biasDir="              + this.biasDir);
         f.outTextLn("darkDir="              + this.darkDir);
         f.outTextLn("flatDir="              + this.flatDir);
         f.outTextLn("lightDir="             + this.lightDir);
         f.outTextLn("saveDir="              + this.saveDir);
         f.outTextLn("masterMode="           + this.masterMode);
         f.outTextLn("equalizeFlatFluxes="   + (this.equalizeFlatFluxes ? "1" : "0"));
         f.outTextLn("autocropStacks="       + (this.autocropStacks     ? "1" : "0"));
         f.outTextLn("saveRegistered="       + (this.saveRegistered     ? "1" : "0"));
         f.outTextLn("weighting="            + this.weighting);
         f.outTextLn("lineRemoval="          + (this.lineRemoval        ? "1" : "0"));
         f.outTextLn("saveHoughIntermediates=" + (this.saveHoughIntermediates ? "1" : "0"));
         f.outTextLn("lineWidth="            + this.lineWidth);
         f.outTextLn("relMinLineSize="       + this.relMinLineSize);
         f.outTextLn("threshMultFromMedian=" + this.threshMultFromMedian);
         f.close();
      } catch (e) {
         console.warningln("GPUWBPP: failed to save config: " + e.message);
      }
   },

   load: function () {
      try {
         if (!File.exists(configFile))
            return;
         let lines = File.readLines(configFile);
         for (let i = 0; i < lines.length; ++i) {
            let line = lines[i];
            let eq = line.indexOf("=");
            if (eq < 0) continue;
            let key = line.substring(0, eq).trim();
            let val = line.substring(eq + 1).trim();
            switch (key) {
               case "astroPipelineParentFolderPath": this.astroPipelineParentFolderPath = val; break;
               case "biasDir":              this.biasDir = val; break;
               case "darkDir":              this.darkDir = val; break;
               case "flatDir":              this.flatDir = val; break;
               case "lightDir":             this.lightDir = val; break;
               case "saveDir":              this.saveDir = val; break;
               case "masterMode":           this.masterMode = val; break;
               case "equalizeFlatFluxes":   this.equalizeFlatFluxes = (val == "1"); break;
               case "autocropStacks":       this.autocropStacks     = (val == "1"); break;
               case "saveRegistered":       this.saveRegistered     = (val == "1"); break;
               case "weighting":            this.weighting = val; break;
               case "lineRemoval":          this.lineRemoval = (val == "1"); break;
               case "saveHoughIntermediates": this.saveHoughIntermediates = (val == "1"); break;
               case "lineWidth":            this.lineWidth = parseInt(val); break;
               case "relMinLineSize":       this.relMinLineSize = parseInt(val); break;
               case "threshMultFromMedian": this.threshMultFromMedian = parseFloat(val); break;
            }
         }
      } catch (e) {
         console.warningln("GPUWBPP: failed to load config: " + e.message);
      }
   }
};

// ---------------------------------------------------------------------------
// Quoting helper for CLI arguments
// ---------------------------------------------------------------------------
function quoteArg(s) {
   if (s == null || s.length == 0)
      return "\"\"";
   return "\"" + s + "\"";
}

// ---------------------------------------------------------------------------
// Build the command-line argument string for AstroPipeline.exe
// ---------------------------------------------------------------------------
function buildArgs(p) {
   let args = [];

   args.push("--bias-dir "  + quoteArg(p.biasDir));
   args.push("--dark-dir "  + quoteArg(p.darkDir));
   args.push("--flat-dir "  + quoteArg(p.flatDir));
   args.push("--light-dir " + quoteArg(p.lightDir));

   if (p.saveDir && p.saveDir.length > 0)
      args.push("--save-dir " + quoteArg(p.saveDir));

   args.push("--vram-budget-mb " + p.vramBudgetMb);

   if (p.masterMode == "recalculate")
      args.push("--recalculate-masters");
   else
      args.push("--use-masters-if-available");

   if (p.equalizeFlatFluxes) args.push("--equalize-flat-fluxes");
   else                      args.push("--no-equalize-flat-fluxes");

   if (p.autocropStacks)     args.push("--autocrop");
   else                      args.push("--no-autocrop");

   if (p.saveRegistered)     args.push("--save-registered");

   args.push("--weighting " + p.weighting);

   if (p.lineRemoval) {
      args.push("--line-removal");
      args.push("--line-width " + p.lineWidth);
      if (p.saveHoughIntermediates)
         args.push("--save-hough-intermediates");
   }

   return args.join(" ");
}

// ---------------------------------------------------------------------------
// Write the platform-appropriate launcher script and return its path.
// ---------------------------------------------------------------------------
function createLauncherScript(scriptPath, exeFolder, exeName, argString) {
   let content;

   if (IS_WIN) {
      content  = "@echo off\r\n";
      content += "set PYTHONUNBUFFERED=1\r\n";
      content += "cd /d \"" + exeFolder + "\"\r\n";
      content += "echo ==========================================\r\n";
      content += "echo  GPUWBPP / AstroPipeline\r\n";
      content += "echo ==========================================\r\n";
      content += "start \"AstroPipeline\" cmd /k \"set PYTHONUNBUFFERED=1 && "
              + exeName + " " + argString + "\"\r\n";
   } else {
      content  = "#!/bin/sh\n";
      content += "export PYTHONUNBUFFERED=1\n";
      content += "cd \"" + exeFolder + "\"\n";
      content += "echo \"==========================================\"\n";
      content += "echo \" GPUWBPP / AstroPipeline\"\n";
      content += "echo \"==========================================\"\n";
      if (CoreApplication.platform == "MACOSX"
          || CoreApplication.platform == "macOS") {
         content += "osascript -e 'tell application \"Terminal\" to do script \""
                 + exeFolder + "/" + exeName + " " + argString + "\"'\n";
      } else {
         content += "./" + exeName + " " + argString + "\n";
      }
   }

   try {
      File.writeTextFile(scriptPath, content);
      if (!IS_WIN) {
         let p = new ExternalProcess;
         p.start("/bin/sh", ["-c", "chmod +x \"" + scriptPath + "\""]);
         p.waitForFinished();
      }
   } catch (e) {
      console.criticalln("GPUWBPP: failed to write launcher script: " + e.message);
      return false;
   }
   return true;
}

// ---------------------------------------------------------------------------
// Main dialog
// ---------------------------------------------------------------------------
function GPUWBPPDialog() {
   this.__base__ = Dialog;
   this.__base__();

   pipelineParameters.load();

   let dlg = this;
   this.windowTitle = TITLE + " " + VERSION;

   // ---- title -----------------------------------------------------------
   this.title = new Label(this);
   this.title.text = TITLE + "   " + VERSION;
   this.title.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   this.title.styleSheet =
      "QLabel { font-size: 16pt; font-weight: bold; color: #000000; }";

   this.subtitle = new Label(this);
   this.subtitle.text =
      "GPU-accelerated weighted batch preprocessing front-end for AstroPipeline";
   this.subtitle.styleSheet = "QLabel { color: #7882a0; }";

   // =====================================================================
   //  Frame Directories section
   // =====================================================================
   let dirSectionLabel = new Label(this);
   dirSectionLabel.text = "Frame Directories";
   dirSectionLabel.styleSheet =
      "QLabel { font-weight: bold; color: #53d8fb; padding-top: 6px; }";

   function makeDirRow(parent, labelText, getter, setter) {
      let row = new HorizontalSizer;
      row.spacing = 4;

      let lbl = new Label(parent);
      lbl.text = labelText + ":";
      lbl.minWidth = 60;
      lbl.textAlignment = TextAlign_Right | TextAlign_VertCenter;

      let edit = new Edit(parent);
      edit.text = getter();
      edit.onTextUpdated = function (v) {
         setter(v);
         pipelineParameters.save();
      };

      let btn = new ToolButton(parent);
      btn.icon = parent.scaledResource(":/icons/select-file.png");
      btn.setScaledFixedSize(24, 24);
      btn.toolTip = "Browse for " + labelText + " directory...";
      btn.onClick = function () {
         let gd = new GetDirectoryDialog;
         gd.initialPath = getter();
         gd.caption = "Select " + labelText + " directory";
         if (gd.execute()) {
            edit.text = gd.directory;
            setter(gd.directory);
            pipelineParameters.save();
         }
      };

      row.add(lbl);
      row.add(edit, 100);
      row.add(btn);
      return row;
   }

   this.biasRow  = makeDirRow(this, "Bias",
      function () { return pipelineParameters.biasDir;  },
      function (v) { pipelineParameters.biasDir = v;    });
   this.darkRow  = makeDirRow(this, "Dark",
      function () { return pipelineParameters.darkDir;  },
      function (v) { pipelineParameters.darkDir = v;    });
   this.flatRow  = makeDirRow(this, "Flat",
      function () { return pipelineParameters.flatDir;  },
      function (v) { pipelineParameters.flatDir = v;    });
   this.lightRow = makeDirRow(this, "Light",
      function () { return pipelineParameters.lightDir; },
      function (v) { pipelineParameters.lightDir = v;   });
   this.saveRow  = makeDirRow(this, "Save",
      function () { return pipelineParameters.saveDir;  },
      function (v) { pipelineParameters.saveDir = v;    });

   // =====================================================================
   //  Options section
   // =====================================================================
   let optionsLabel = new Label(this);
   optionsLabel.text = "Options";
   optionsLabel.styleSheet =
      "QLabel { font-weight: bold; color: #53d8fb; padding-top: 6px; }";

   // ----- Master mode dropdown -----
   this.masterLabel = new Label(this);
   this.masterLabel.text = "Master frames:";
   this.masterLabel.minWidth = 100;

   this.masterCombo = new ComboBox(this);
   this.masterCombo.editEnabled = false;
   this.masterCombo.addItem("Use masters if available");
   this.masterCombo.addItem("Recalculate all masters");
   this.masterCombo.currentItem =
      (pipelineParameters.masterMode == "recalculate") ? 1 : 0;
   this.masterCombo.toolTip =
      "Use cached master frames when found, or always rebuild from raw data.";
   this.masterCombo.onItemSelected = function (idx) {
      pipelineParameters.masterMode =
         (idx == 1) ? "recalculate" : "use_if_available";
      pipelineParameters.save();
   };

   this.masterSizer = new HorizontalSizer;
   this.masterSizer.spacing = 4;
   this.masterSizer.add(this.masterLabel);
   this.masterSizer.add(this.masterCombo);
   this.masterSizer.addStretch();

   // ----- Stacking weight dropdown -----
   this.weightLabel = new Label(this);
   this.weightLabel.text = "Stacking Weight:";
   this.weightLabel.minWidth = 100;

   this.weightCombo = new ComboBox(this);
   this.weightCombo.editEnabled = false;
   this.weightCombo.addItem("PSF Signal Weight");
   this.weightCombo.addItem("None");
   this.weightCombo.currentItem =
      (pipelineParameters.weighting == "none") ? 1 : 0;
   this.weightCombo.toolTip =
      "Frame weighting algorithm for the final mean stack.\n" +
      "PSF Signal Weight = SNR^2 * sharpness / eccentricity.";
   this.weightCombo.onItemSelected = function (idx) {
      pipelineParameters.weighting = (idx == 1) ? "none" : "psf_signal";
      pipelineParameters.save();
   };

   this.weightSizer = new HorizontalSizer;
   this.weightSizer.spacing = 4;
   this.weightSizer.add(this.weightLabel);
   this.weightSizer.add(this.weightCombo);
   this.weightSizer.addStretch();

   // ----- Checkboxes -----
   this.equalizeChk = new CheckBox(this);
   this.equalizeChk.text = "Equalize flat fluxes";
   this.equalizeChk.checked = pipelineParameters.equalizeFlatFluxes;
   this.equalizeChk.toolTip =
      "Scale each flat to a common median before stacking the master flat.";
   this.equalizeChk.onCheck = function (v) {
      pipelineParameters.equalizeFlatFluxes = v;
      pipelineParameters.save();
   };

   this.autocropChk = new CheckBox(this);
   this.autocropChk.text = "Autocrop stacked images";
   this.autocropChk.checked = pipelineParameters.autocropStacks;
   this.autocropChk.toolTip =
      "Crop the final stack to the rectangular region covered by every frame.";
   this.autocropChk.onCheck = function (v) {
      pipelineParameters.autocropStacks = v;
      pipelineParameters.save();
   };

   this.chkRow1 = new HorizontalSizer;
   this.chkRow1.spacing = 24;
   this.chkRow1.addSpacing(100);
   this.chkRow1.add(this.equalizeChk);
   this.chkRow1.add(this.autocropChk);
   this.chkRow1.addStretch();

   this.saveRegisteredChk = new CheckBox(this);
   this.saveRegisteredChk.text = "Save registered frames";
   this.saveRegisteredChk.checked = pipelineParameters.saveRegistered;
   this.saveRegisteredChk.toolTip =
      "Save each registered frame to <light-dir>/Registered/.";
   this.saveRegisteredChk.onCheck = function (v) {
      pipelineParameters.saveRegistered = v;
      pipelineParameters.save();
   };

   this.chkRow2 = new HorizontalSizer;
   this.chkRow2.spacing = 24;
   this.chkRow2.addSpacing(100);
   this.chkRow2.add(this.saveRegisteredChk);
   this.chkRow2.addStretch();

   // =====================================================================
   //  Satellite Trail Removal section
   // =====================================================================
   let trailSectionLabel = new Label(this);
   trailSectionLabel.text = "Satellite Trail Removal";
   trailSectionLabel.styleSheet =
      "QLabel { font-weight: bold; color: #53d8fb; padding-top: 6px; }";

   this.lineRemovalChk = new CheckBox(this);
   this.lineRemovalChk.text = "Enable satellite trail removal";
   this.lineRemovalChk.checked = pipelineParameters.lineRemoval;
   this.lineRemovalChk.toolTip =
      "Detect and mask satellite/aeroplane trails before stacking.";
   this.lineRemovalChk.onCheck = function (v) {
      pipelineParameters.lineRemoval = v;
      pipelineParameters.save();
      dlg.updateTrailControls();
   };

   this.saveHoughChk = new CheckBox(this);
   this.saveHoughChk.text = "Save intermediate files";
   this.saveHoughChk.checked = pipelineParameters.saveHoughIntermediates;
   this.saveHoughChk.toolTip =
      "Save intermediate images and median frames for inspection.";
   this.saveHoughChk.onCheck = function (v) {
      pipelineParameters.saveHoughIntermediates = v;
      pipelineParameters.save();
   };

   this.lineWidthCtrl = new NumericControl(this);
   this.lineWidthCtrl.label.text = "Line width (px):";
   this.lineWidthCtrl.label.minWidth = 130;
   this.lineWidthCtrl.setRange(1, 21);
   this.lineWidthCtrl.slider.setRange(1, 21);
   this.lineWidthCtrl.setPrecision(0);
   this.lineWidthCtrl.setValue(pipelineParameters.lineWidth);
   this.lineWidthCtrl.toolTip = "Width in pixels of the masks drawn over detected lines.";
   this.lineWidthCtrl.onValueUpdated = function (v) {
      pipelineParameters.lineWidth = Math.round(v);
      pipelineParameters.save();
   };

   this.relMinLineCtrl = new NumericControl(this);
   this.relMinLineCtrl.label.text = "Min line size (% diag):";
   this.relMinLineCtrl.label.minWidth = 130;
   this.relMinLineCtrl.setRange(1, 50);
   this.relMinLineCtrl.slider.setRange(1, 50);
   this.relMinLineCtrl.setPrecision(0);
   this.relMinLineCtrl.setValue(pipelineParameters.relMinLineSize);
   this.relMinLineCtrl.toolTip =
      "Shortest line considered, as a percentage of the image diagonal.";
   this.relMinLineCtrl.onValueUpdated = function (v) {
      pipelineParameters.relMinLineSize = Math.round(v);
      pipelineParameters.save();
   };

   this.threshMultCtrl = new NumericControl(this);
   this.threshMultCtrl.label.text = "Range threshold mult:";
   this.threshMultCtrl.label.minWidth = 130;
   this.threshMultCtrl.setRange(1.0, 20.0);
   this.threshMultCtrl.slider.setRange(10, 200);
   this.threshMultCtrl.setPrecision(1);
   this.threshMultCtrl.setValue(pipelineParameters.threshMultFromMedian);
   this.threshMultCtrl.toolTip =
      "Detection threshold expressed as a multiple of the per-frame median.";
   this.threshMultCtrl.onValueUpdated = function (v) {
      pipelineParameters.threshMultFromMedian = v;
      pipelineParameters.save();
   };

   this.updateTrailControls = function () {
      let on = pipelineParameters.lineRemoval;
      this.saveHoughChk.enabled  = on;
      this.lineWidthCtrl.enabled = on;
      this.relMinLineCtrl.enabled = on;
      this.threshMultCtrl.enabled = on;
   };

   // =====================================================================
   //  Setup / instance / run buttons
   // =====================================================================
   this.setupButton = new ToolButton(this);
   this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
   this.setupButton.setScaledFixedSize(24, 24);
   this.setupButton.toolTip =
      "Set the folder containing the AstroPipeline executable\n" +
      "(currently: " + (pipelineParameters.astroPipelineParentFolderPath || "<not set>") + ")";
   this.setupButton.onClick = function () {
      let gd = new GetDirectoryDialog;
      gd.initialPath = pipelineParameters.astroPipelineParentFolderPath;
      gd.caption = "Select folder containing " + EXE_NAME;
      if (gd.execute()) {
         pipelineParameters.astroPipelineParentFolderPath = gd.directory;
         pipelineParameters.save();
         dlg.setupButton.toolTip =
            "Set the folder containing the AstroPipeline executable\n" +
            "(currently: " + gd.directory + ")";
      }
   };

   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "Save a new instance of this script";
   this.newInstanceButton.onMousePress = function () {
      this.dialog.newInstance();
   }.bind(this);

   this.runButton = new PushButton(this);
   this.runButton.text = "Create Masters, Calibrate, Register, Locally Normalize, and Stack";
   this.runButton.icon = this.scaledResource(":/icons/power.png");
   this.runButton.styleSheet =
      "QPushButton { background-color: #e94560; color: #ffffff; "
      + "font-weight: bold; padding: 8px 14px; }";
   this.runButton.onClick = function () {
      dlg.onRun();
   };

   this.cancelButton = new PushButton(this);
   this.cancelButton.text = "Close";
   this.cancelButton.icon = this.scaledResource(":/icons/cancel.png");
   this.cancelButton.onClick = function () {
      dlg.cancel();
   };

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.newInstanceButton);
   this.buttonsSizer.add(this.setupButton);
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add(this.runButton);
   this.buttonsSizer.add(this.cancelButton);

   // =====================================================================
   //  Run handler
   // =====================================================================
   this.onRun = function () {
      if (!pipelineParameters.astroPipelineParentFolderPath
          || pipelineParameters.astroPipelineParentFolderPath.length == 0) {
         (new MessageBox(
            "The AstroPipeline executable folder has not been set.\n\n"
            + "Click the wrench icon to select the folder containing " + EXE_NAME + ".",
            TITLE, StdIcon_Error, StdButton_Ok)).execute();
         return;
      }
      let exeFolder = pipelineParameters.astroPipelineParentFolderPath;
      let exePath = exeFolder + pathSeparator + EXE_NAME;
      if (!File.exists(exePath)) {
         (new MessageBox(
            "Could not find the AstroPipeline executable at:\n\n" + exePath
            + "\n\nUse the wrench icon to select the correct folder.",
            TITLE, StdIcon_Error, StdButton_Ok)).execute();
         return;
      }
      let missing = [];
      if (!pipelineParameters.biasDir  || !File.directoryExists(pipelineParameters.biasDir))  missing.push("Bias");
      if (!pipelineParameters.darkDir  || !File.directoryExists(pipelineParameters.darkDir))  missing.push("Dark");
      if (!pipelineParameters.flatDir  || !File.directoryExists(pipelineParameters.flatDir))  missing.push("Flat");
      if (!pipelineParameters.lightDir || !File.directoryExists(pipelineParameters.lightDir)) missing.push("Light");
      if (missing.length > 0) {
         (new MessageBox(
            "The following required directories are missing or invalid:\n\n  "
            + missing.join(", "),
            TITLE, StdIcon_Error, StdButton_Ok)).execute();
         return;
      }

      let argString = buildArgs(pipelineParameters);
      let launcherPath = scriptTempDir + pathSeparator
                       + "run_astropipeline" + SCRIPT_EXT;

      console.show();
      console.writeln("---------------------------------------------------");
      console.writeln(TITLE + " " + VERSION + ": launching AstroPipeline");
      console.writeln("---------------------------------------------------");
      console.writeln("Executable folder : " + exeFolder);
      console.writeln("Executable        : " + EXE_NAME);
      console.writeln("Argument string   :");
      console.writeln("  " + argString);
      console.flush();

      if (!createLauncherScript(launcherPath, exeFolder, EXE_NAME, argString))
         return;

      try {
         let proc = new ExternalProcess;
         if (IS_WIN) {
            proc.start(CMD_EXEC, ["/c", launcherPath]);
         } else {
            proc.start(CMD_EXEC, [launcherPath]);
         }
         proc.waitForFinished(10000);
         console.writeln("AstroPipeline launched in a separate console window.");
         console.writeln("Watch its console window for progress and timings.");
      } catch (e) {
         console.criticalln("Failed to launch AstroPipeline: " + e.message);
         (new MessageBox(
            "Failed to launch AstroPipeline:\n\n" + e.message,
            TITLE, StdIcon_Error, StdButton_Ok)).execute();
      }
      console.flush();
   };

   // =====================================================================
   //  Master vertical layout
   // =====================================================================
   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 4;

   this.sizer.add(this.title);
   this.sizer.add(this.subtitle);
   this.sizer.addSpacing(8);

   this.sizer.add(dirSectionLabel);
   this.sizer.add(this.biasRow);
   this.sizer.add(this.darkRow);
   this.sizer.add(this.flatRow);
   this.sizer.add(this.lightRow);
   this.sizer.add(this.saveRow);
   this.sizer.addSpacing(4);

   this.sizer.add(optionsLabel);
   this.sizer.add(this.masterSizer);
   this.sizer.add(this.weightSizer);
   this.sizer.add(this.chkRow1);
   this.sizer.add(this.chkRow2);
   this.sizer.addSpacing(4);

   this.sizer.add(trailSectionLabel);
   this.sizer.add(this.lineRemovalChk);
   this.sizer.add(this.saveHoughChk);
   this.sizer.add(this.lineWidthCtrl);
   this.sizer.add(this.relMinLineCtrl);
   this.sizer.add(this.threshMultCtrl);
   this.sizer.addSpacing(8);

   this.sizer.add(this.buttonsSizer);

   this.updateTrailControls();
   this.adjustToContents();
   this.setMinWidth(720);
}
GPUWBPPDialog.prototype = new Dialog;

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------
function main() {
   let dlg = new GPUWBPPDialog;
   dlg.execute();
}

main();
